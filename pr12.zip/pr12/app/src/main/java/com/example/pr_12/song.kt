package com.example.pr_12

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class song : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_song)
    }
}
